package Playtopia;

import org.springframework.data.repository.CrudRepository;

public interface ContactUsRepository extends CrudRepository<ContactUs,Long>{

}
