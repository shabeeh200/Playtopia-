package Playtopia;

import java.util.List;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;

public interface CommentsRepository extends CrudRepository<Comments,Long>{
	
	 List<Comments> findByBlog_BlogId(Long blogId);
}
