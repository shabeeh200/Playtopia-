package Playtopia;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
@Entity
public class Comments {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long commentid;

    @ManyToOne
    @JoinColumn(name = "blogId")
    private Blogs blog;

    @ManyToOne
    @JoinColumn(name = "customerid")
    private Customer customer;

    private String message;
	public Comments() {
		super();
	}



	public Comments(Long id, Blogs blog, Customer customer, String message) {
		super();
		this.commentid = id;
		this.blog = blog;
		this.customer = customer;
		this.message = message;
	}

	

	public Blogs getBlog() {
		return blog;
	}

	public void setBlog(Blogs blog) {
		this.blog = blog;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
    
}
