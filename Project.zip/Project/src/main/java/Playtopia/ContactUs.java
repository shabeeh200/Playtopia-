package Playtopia;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class ContactUs {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
private String email;
private String name;
private String comment;
public ContactUs(Long id,String email, String name, String comment) {
	super();
	this.id=id;
	this.email = email;
	this.name = name;
	this.comment = comment;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getComment() {
	return comment;
}
public void setComment(String comment) {
	this.comment = comment;
}
public ContactUs() {
	super();
}

}
