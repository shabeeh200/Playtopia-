package Playtopia;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;
@Component


public interface BlogsRepository extends CrudRepository<Blogs,Long>{

}
