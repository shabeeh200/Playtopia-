package Playtopia;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
public class PlaytopiaController {
	 
	@Autowired
	 public final PlaytopiaService playservice;
	
	public PlaytopiaController(PlaytopiaService playservice) {
		super();
		this.playservice = playservice;
	}
	
	//Gallery APIS
	@GetMapping("GetGallery")
	public List<Gallery> getGalleryFromService(){
		 return playservice.getGallery();
	 }
	@PostMapping("AddGallery")
	public void AddGallery(@RequestBody Gallery gallery){
		playservice.addGalllery( gallery);
	 }
	@DeleteMapping("DeleteGallery/{id}")
    public void deleteGallery(@PathVariable Long id) {
    	playservice.deleteGallery(id);
    }
	@PutMapping("UpdateGallery/{id}")
	public void updategallery(@PathVariable Long id,@RequestBody Gallery gallery  )
	{
		playservice.updateGallery(gallery, id);

	}
	 @GetMapping("GetGalleryID/{id}")
	    public Gallery getgalleryBYID(@PathVariable Long id) {
	    	return playservice.getGalleryById(id);
	    }
	//Blogs APIS
	@GetMapping("GetBlog")
	public List<Blogs> getBlogFromService(){
		 return playservice.getblogs();
	 }
	@PostMapping("Addblogs")
	public void AddBlogs(@RequestBody Blogs blog){
		playservice.addblogs(blog);
	 }
	@PutMapping("UpdateBlog/{id}")
	public void updateblog(@PathVariable Long id,@RequestBody Blogs blog  )
	{
		playservice.updateBlogs(blog,id );

	}

    @DeleteMapping("DeleteBlog/{id}")
    public void deleteBlogs(@PathVariable Long id) {
    	playservice.deleteBlogs(id);
    }
    @GetMapping("GetBlogID/{id}")
    public Blogs getBlog(@PathVariable Long id) {
    	return playservice.getBlogById(id);
    }
	//Games APIS
	@GetMapping("GetGame")
	public List<Games> getGamesFromService(){
		 return playservice.getGames();
	 }
	@PostMapping("AddGames")
	public void AddGames(@RequestBody Games game){
		playservice.addGames(game);
	}
	@PutMapping("UpdateGame/{id}")
	public void updateGame(@PathVariable Long id,@RequestBody Games game  )
	{
		playservice.updateGames(game, id);

	}

    @DeleteMapping("DeleteGame/{id}")
    public void deleteGame(@PathVariable Long id) {
    	playservice.deleteGames(id);
    }
    @GetMapping("GetGameID/{id}")
    public Games getGame(@PathVariable Long id) {
    	return playservice.getGamesById(id);
    	}
    @GetMapping("GetGamesByCategory/{category}")
    public List<Games> getGamesByCategory(@PathVariable String category){
    	return playservice.getGamesByCategory(category);
    }
	//Customer APIS
	@GetMapping("GetCustomer")
		public List<Customer> getCustomerFromService(){
			 return playservice.getCustomer();
		 }
		@PostMapping("Addcustomer")
		public void AddCustomer(@RequestBody Customer cust){
			playservice.addCustomer(cust);
		}
		
	//Login
		@PostMapping("LogIn")
	public ResponseEntity<String> logIN(@RequestBody Customer loginRequest) {
			
		Customer customer=playservice.login(loginRequest.getEmail(), loginRequest.getPassword());
	    if (customer != null) {
        	return ResponseEntity.ok(String.valueOf(customer.getCustomerid()));
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid email or password");
        }
		}
	//VideoGuides
		@PostMapping("AddVideo")
		public void AddVideoGuide(@RequestBody VideoGuides videoGuide){
			playservice.addVideo(videoGuide);
		 }
		@GetMapping("GetVideo")
		public List<VideoGuides> getVideoFromService(){
			 return playservice.getVideoGuide();
		 }
		 @DeleteMapping("DeleteVideo/{id}")
		public void deleteVideo(@PathVariable Long id) {
		    	playservice.deleteVideo(id);
		    }
	
		 @PutMapping("UpdateVideo/{id}")
		public void updatevideo(@PathVariable Long id,@RequestBody VideoGuides video )
			{
				playservice.updateVideo(video, id);

			}
		 @GetMapping("GetVideoID/{id}")
		    public VideoGuides getVideo(@PathVariable Long id) {
		    	return playservice.getVideoById(id);
		    }
	//ContactUs
		 @PostMapping("AddContact")
			public void AddContact(@RequestBody ContactUs contact){
				playservice.addcontact(contact);
			 }
			@GetMapping("GetContact")
			public List<ContactUs> getContactFromService(){
				 return playservice.getContact();
			 }
//Comments
			@PostMapping("AddComments")
			public void AddComments(@RequestBody Comments comment){
				playservice.addComments(comment);
			 }
			@GetMapping("GetComment/{id}")
			public List<Comments> getCommentFromService(@PathVariable Long id){
				 return playservice.getCommentsByBlogId(id);
			 }
//Reviews
			@PostMapping("AddReview")
			public void AddReviews(@RequestBody Reviews review){
				playservice.addReviews(review);
			 }
			@GetMapping("GetReviews/{gameID}")
			public List<Reviews> getReviewsFromService(@PathVariable Long gameID){
				return playservice.getReviewByGameID(gameID);
			}
			
		
}
