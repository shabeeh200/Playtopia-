package Playtopia;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Gallery {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
    private long galleryId;
	
private String title;
private String galleryDescription;
private String category;

public Gallery() {
	super();
}
public Gallery(long galleryId, String title, String galleryDescription, String category_id) {
	super();
	this.galleryId = galleryId;
	this.title = title;
	this.galleryDescription = galleryDescription;
	this.category= category_id;
}
public long getGalleryId() {
	return galleryId;
}
public void setGalleryId(long galleryId) {
	this.galleryId = galleryId;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public String getGalleryDescription() {
	return galleryDescription;
}
public void setGalleryDescription(String galleryDescription) {
	this.galleryDescription = galleryDescription;
}
public String getCategory() {
	return category;
}
public void setCategory(String category) {
	this.category = category;
}


}
