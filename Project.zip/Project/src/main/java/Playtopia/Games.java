package Playtopia;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
//Data Layer Class
@Entity
public class Games {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
private Long gameID;
	
private String name;
private String descrption;
private String category;
private String downloadLink;
private String gameImage;

public Games() {
	super();
}
public Games(Long gameID, String name, String descrption, String category, String downloadLink, String gameImage) {
	super();
	this.gameID = gameID;
	this.name = name;
	this.descrption = descrption;
	this.category = category;
	this.downloadLink = downloadLink;
	this.gameImage = gameImage;
}
public Long getGameID() {
	return gameID;
}
public void setGameID(Long gameID) {
	this.gameID = gameID;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDescrption() {
	return descrption;
}
public void setDescrption(String descrption) {
	this.descrption = descrption;
}

public String getCategory() {
	return category;
}
public void setCategory(String category) {
	this.category = category;
}
public String getDownloadLink() {
	return downloadLink;
}
public void setDownloadLink(String downloadLink) {
	this.downloadLink = downloadLink;
}
public String getGameImage() {
	return gameImage;
}
public void setGameImage(String gameImage) {
	this.gameImage = gameImage;
}
}
