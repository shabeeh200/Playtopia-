package Playtopia;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service // indicating that its a Bean or component
public class PlaytopiaService {
	@Autowired
 private BlogsRepository br;
	@Autowired
 private GalleryRepository gr;
	@Autowired
 private GamesRepository gm;
	@Autowired
 private CustomerRepository cm;
	@Autowired
 private VideoGuideRepository vgr;
	@Autowired
private ContactUsRepository cu;
	@Autowired
private CommentsRepository co;
	@Autowired
private ReviewRepository rw;
	//constructor /
	
//Post Functions 
 //Blog
	 public void addblogs(Blogs bl) {
		 br.save(bl);
	 }
public PlaytopiaService(BlogsRepository br, GalleryRepository gr, GamesRepository gm, CustomerRepository cm,
			VideoGuideRepository vgr, ContactUsRepository cu, CommentsRepository co, ReviewRepository rw) {
		super();
		this.br = br;
		this.gr = gr;
		this.gm = gm;
		this.cm = cm;
		this.vgr = vgr;
		this.cu = cu;
		this.co = co;
		this.rw = rw;
	}
// Gallery 
	 public void addGalllery(Gallery bl) {
		 gr.save(bl);
	 }
	// Games 
		 public void addGames(Games bl) {
			 gm.save(bl);
		 }
	//Customer
	 public void addCustomer(Customer bl) {
			 cm.save(bl);
		 }
	 public void addVideo(VideoGuides vg) {
		 vgr.save(vg);
	 }
	 //ContactUs
	 public void addcontact(ContactUs contact) {
		 cu.save(contact);
	 }
	//Comments
	 public void addComments(Comments comment){
		 Long blogId = comment.getBlog().getBlogId();
		 Long customerId = comment.getCustomer().getCustomerid();
	        Blogs existingBlog = br.findById(blogId).orElse(null);
	        Customer existingCustomer = cm.findById(customerId).orElse(null);
	        if (existingBlog != null) {
	            comment.setBlog(existingBlog);
	            comment.setCustomer(existingCustomer);
	            co.save(comment);
	        } else {
	        	 throw new NoSuchElementException("Blog not found");
	        }
		
	 }
	//Review
		 public void addReviews(Reviews review){
			 rw.save(review);
		 }
//Get Function
	 //Blogs
 public List<Blogs> getblogs(){
	 List<Blogs> blog=new ArrayList<Blogs>();
	 br.findAll().forEach(blog::add);
		return blog;
 }
    //Gallery
 public List<Gallery> getGallery(){
	 List<Gallery> image=new ArrayList<Gallery>();
	 gr.findAll().forEach(image::add);
		return image;
 }
	//Games
 public List<Games> getGames(){
	 List<Games> game=new ArrayList<Games>();
	 gm.findAll().forEach(game::add);
		return game;
 }
// Customer
 public List<Customer> getCustomer(){
	 List<Customer> customer=new ArrayList<Customer>();
	 cm.findAll().forEach(customer::add);
		return customer;
 }
 //VideoGuides
public List<VideoGuides> getVideoGuide(){
 List<VideoGuides> video=new ArrayList<VideoGuides>();
 vgr.findAll().forEach(video::add);
	return video;
}
//ContactUs
public List<ContactUs> getContact(){
	List<ContactUs> contact=new ArrayList<ContactUs>();
	cu.findAll().forEach(contact::add);
	return contact;
}
//Comment
public List<Comments> getCommentsByBlogId(Long blogId){
	return co.findByBlog_BlogId(blogId);
}
//Reviews 
public List<Reviews> getReviewByGameID(Long gameID){
	return rw.findByGame_GameID(gameID);
}
 ///////////////////update functions
 public void updateBlogs(Blogs Updateblog,Long id) {
	 Optional<Blogs> existingBookOptional = br.findById(id);
	if (existingBookOptional.isPresent()) {
	Blogs existingBlog = existingBookOptional.get();
	if (Updateblog.getBlogImage() != null && !Updateblog.getBlogImage().isEmpty()) {
	    existingBlog.setBlogImage(Updateblog.getBlogImage());
	}

    existingBlog.setCategories(Updateblog.getCategories());
	existingBlog.setContent(Updateblog.getContent());
    existingBlog.setQuote(Updateblog.getQuote());
    existingBlog.setTitle(Updateblog.getTitle());
	br.save(existingBlog);
	}

 }
 public void updateGallery(Gallery UpdateGallery,Long id) {
	 Optional<Gallery> existingGalleryOptional = gr.findById(id);
	if (existingGalleryOptional.isPresent()) {
	Gallery existingGallery = existingGalleryOptional.get();
	if (UpdateGallery.getTitle() != null && !UpdateGallery.getTitle().isEmpty()) {
	    existingGallery.setTitle(UpdateGallery.getTitle());
	}
	existingGallery.setGalleryDescription(UpdateGallery.getGalleryDescription());
	existingGallery.setCategory(UpdateGallery.getCategory());
    gr.save(existingGallery);
	}

 }
 public void updateVideo(VideoGuides UpdateVideo,Long id) {
	 Optional<VideoGuides> existingVideoOptional = vgr.findById(id);
	if (existingVideoOptional.isPresent()) {
	VideoGuides existingVideo = existingVideoOptional.get();
	if (UpdateVideo.getVideo()!= null && !UpdateVideo.getVideo().isEmpty()) {
	    existingVideo.setVideo(UpdateVideo.getVideo());
	}
	existingVideo.setDescription(UpdateVideo.getDescription());
	existingVideo.setTitle(UpdateVideo.getTitle());
    vgr.save(existingVideo);
	}

 }
 public void updateGames(Games UpdateGame,Long id) {
	 Optional<Games> existingOptional = gm.findById(id);
	if (existingOptional.isPresent()) {
		
Games existinggame = existingOptional.get();
existinggame.setCategory(UpdateGame.getCategory());
existinggame.setDescrption(UpdateGame.getDescrption());
existinggame.setName(UpdateGame.getName());
	if (UpdateGame.getGameImage() != null && !UpdateGame.getGameImage().isEmpty()) {
	    existinggame.setGameImage(UpdateGame.getGameImage());
	}
	if (UpdateGame.getDownloadLink()!= null && !UpdateGame.getDownloadLink().isEmpty()) {
	    existinggame.setDownloadLink(UpdateGame.getDownloadLink());
	}
   
gm.save(existinggame);
	}
 }
 //Delete API function
 public void deleteBlogs(Long id) {
	 br.deleteById(id);
	
 }
 public void deleteGallery(Long id) {
	 gr.deleteById(id);
 }
 public void deleteVideo(Long id) {
	 vgr.deleteById(id);
 }
 public void deleteGames(Long id) {
	 gm.deleteById(id);
 }
 
 //GetId
 public Blogs getBlogById(Long id) {
	    return br.findById(id).orElse(null);
	}
 public Gallery getGalleryById(Long id) {
	    return gr.findById(id).orElse(null);
	}
 public VideoGuides getVideoById(Long id) {
	    return vgr.findById(id).orElse(null);
	}
 public Games getGamesById(Long id) {
	    return gm.findById(id).orElse(null);
	}
 //get category
 public List<Games> getGamesByCategory(String Category){
	 return gm.findByCategory(Category);
 }
 //Login
 public Customer login(String email, String password) {
     // Fetch user by email from the database
     Customer user = cm.findByEmail(email);

     if (user != null && user.getPassword().equals(password)) {
         return user; // User found and password matches
     } else {
         return null; // User not found or password doesn't match
     }
 }
}
