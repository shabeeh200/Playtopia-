package Playtopia;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;
@Component
public interface GamesRepository extends  CrudRepository<Games,Long> {
	 List<Games> findByCategory(String category);
}
