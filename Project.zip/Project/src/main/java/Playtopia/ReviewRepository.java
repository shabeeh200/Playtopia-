package Playtopia;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface ReviewRepository extends  CrudRepository<Reviews,Long>{
	List<Reviews> findByGame_GameID(Long gameID);
}
