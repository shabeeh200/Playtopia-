package Playtopia;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

//Data Layer Class
@Entity
public class Blogs {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long blogId;
	
	private String title,categories,content,quote,blogImage;
	private String created_at;

	public Blogs() {
		super();
	}

	public Blogs(Long id, String title, String categories, String content, String quote, String blogImage,
			String created_at) {
		super();
		this.blogId = id;
		this.title = title;
		this.categories = categories;
		this.content = content;
		this.quote = quote;
		this.blogImage = blogImage;
		this.created_at = created_at;
	}
	
	public Long getBlogId() {
		return blogId;
	}

	public void setBlogId(Long blogId) {
		this.blogId = blogId;
	}

	public String getBlogImage() {
		return blogImage;
	}

	public void setBlogImage(String blogImage) {
		this.blogImage = blogImage;
	}

	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCategories() {
		return categories;
	}
	public void setCategories(String categories) {
		this.categories = categories;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getQuote() {
		return quote;
	}
	public void setQuote(String quote) {
		this.quote = quote;
	}
	public String getCreated_at() {
		return created_at;
	}
	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}
	
}
