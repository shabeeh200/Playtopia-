package Playtopia;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Reviews {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long reviewID;
	
	@ManyToOne
    @JoinColumn(name = "gameID")
    private Games game;

    @ManyToOne
    @JoinColumn(name = "customerid")
    private Customer customer;
    
	private String message,created_at;
	private double ratings;
	public Reviews(Long reviewID, Games game, Customer customer, String message, String created_at, double ratings) {
		super();
		this.reviewID = reviewID;
		this.game = game;
		this.customer = customer;
		this.message = message;
		this.created_at = created_at;
		this.ratings = ratings;
	}
	public Reviews() {
		super();
	}
	public Long getReviewID() {
		return reviewID;
	}
	public void setReviewID(Long reviewID) {
		this.reviewID = reviewID;
	}
	public Games getGame() {
		return game;
	}
	public void setGame(Games game) {
		this.game = game;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getCreated_at() {
		return created_at;
	}
	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}
	public double getRatings() {
		return ratings;
	}
	public void setRatings(double ratings) {
		this.ratings = ratings;
	}
	
}
